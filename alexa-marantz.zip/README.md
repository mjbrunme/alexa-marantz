# alexa-marantz
Lambda function for controlling the Marantz SR5010 / SR6010 Receiver through an Alexa home automation skill.  You will need to create a new skill in order to implement this, and configure several parameters on the script itself for target devices.

This particular function also ties into the Sony Bravia series TV APIs, and some of the end-functionality relies on the CEC functionality of the TV and Receiver together.  Still, it's a useful method for seeing how these skills can work and for controls for the Marantz receivers and Sony TVs.
